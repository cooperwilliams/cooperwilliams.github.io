import Worker from "/canvas/worker.js";

export default function() {

}