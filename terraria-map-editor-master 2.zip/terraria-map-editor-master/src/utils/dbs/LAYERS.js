const LAYERS = {
    BACKGROUND: 0,
    WALLS: 1,
    //WALLS_PAINTED: 5,
    TILES: 2,
    //TILES_PAINTED: 6,
    LIQUIDS: 3,
    WIRES: 4
}

export default Object.freeze(LAYERS);